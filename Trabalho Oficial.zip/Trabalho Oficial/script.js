// ReservaIF 2.0 - Main JavaScript File with Perfect Synchronization
// ===================================================================

// State Management - UNIFIED RESERVATION LIST (Single Source of Truth)
const state = {
    currentRole: 'professor',
    currentPage: 'dashboard',
    isLoggedIn: false,
    user: null,
    selectedRoom: null,
    // ALL reservations in ONE list - synchronized across all roles
    allReservations: [
        { id: 1, room: 'A2-01 - Laboratório de Informática', roomCode: 'A2-01', date: '10/12/2024', startTime: '14:00', duration: 2, endTime: '16:00', purpose: 'Aula de Engenharia de Software', status: 'approved', requester: 'João Vitor', requesterId: 'prof-1', createdAt: '2024-12-05T10:00:00Z', approvedBy: 'Prof. Silva' },
        { id: 2, room: 'B4-06 - Auditório', roomCode: 'B4-06', date: '11/12/2024', startTime: '10:00', duration: 2, endTime: '12:00', purpose: 'Apresentação de Projeto', status: 'pending', requester: 'João Vitor', requesterId: 'prof-1', createdAt: '2024-12-05T11:30:00Z' },
        { id: 3, room: 'A3-05 - Sala de Aula', roomCode: 'A3-05', date: '12/12/2024', startTime: '13:00', duration: 2, endTime: '15:00', purpose: 'Aula Prática - Guilherme Silva', status: 'pending', requester: 'Guilherme Silva', requesterId: 'prof-2', createdAt: '2024-12-05T12:00:00Z' }
    ],
    problems: [
        { id: 1, room: 'A2-01', equipment: 'Projetor', description: 'Projetor não liga', status: 'pending', priority: 'alta', date: '05/12/2024', reporter: 'João Vitor' },
        { id: 2, room: 'B4-06', equipment: 'Ar Condicionado', description: 'Ar condicionado não esfria', status: 'in-progress', priority: 'media', date: '04/12/2024', reporter: 'Carlos Eduardo' }
    ],
    rooms: [
        { id: 101, name: 'A2-01 - Laboratório de Informática', capacity: 30, building: 'Bloco A', floor: 2, status: 'available', equipment: 'Projetor, Ar Condicionado, Quadro' },
        { id: 102, name: 'B4-06 - Auditório', capacity: 100, building: 'Bloco B', floor: 4, status: 'available', equipment: 'Projetor, Som, Ar Condicionado' },
        { id: 103, name: 'A3-05 - Sala de Aula', capacity: 40, building: 'Bloco A', floor: 3, status: 'available', equipment: 'Quadro, Ar Condicionado' },
        { id: 104, name: 'C1-02 - Laboratório de Eletrônica', capacity: 25, building: 'Bloco C', floor: 1, status: 'maintenance', equipment: 'Bancadas, Ferramentas' }
    ],
    notifications: [
        { id: 1, type: 'approval', title: 'Reserva Aprovada', message: 'Sua reserva para a Sala 101 em 10 de Dezembro foi aprovada pelo Coordenador Silva.', time: '2 horas atrás', read: false },
        { id: 2, type: 'maintenance', title: 'Sala Bloqueada para Manutenção', message: 'A Sala 102 foi bloqueada para manutenção crítica. Sua reserva foi cancelada automaticamente.', time: '4 horas atrás', read: false },
        { id: 3, type: 'pending', title: 'Reserva Pendente de Aprovação', message: 'Sua solicitação de reserva para a Sala 103 está aguardando aprovação do coordenador.', time: '1 dia atrás', read: true }
    ]
};

// ========== HELPER FUNCTIONS FOR TIME CONFLICT DETECTION ==========

function timeToMinutes(timeStr) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
}

function minutesToTime(minutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
}

function hasTimeConflict(roomCode, date, startTime, duration, statusesToCheck = ['approved'], reservationIdToExclude = null) {
    // Find all reservations for this room on this date with the specified statuses
    const reservationsToCheck = state.allReservations.filter(res => 
        res.roomCode === roomCode && 
        res.date === date && 
        res.id !== reservationIdToExclude &&
        statusesToCheck.includes(res.status)
    );
    
    const newStartMinutes = timeToMinutes(startTime);
    const newEndMinutes = newStartMinutes + (duration * 60);
    
    for (const reservation of reservationsToCheck) {
        const existingStartMinutes = timeToMinutes(reservation.startTime);
        const existingEndMinutes = timeToMinutes(reservation.endTime);
        
        // Check if there's any overlap
        if (newStartMinutes < existingEndMinutes && newEndMinutes > existingStartMinutes) {
            return {
                hasConflict: true,
                conflictingReservation: reservation,
                message: `Conflito de horário! A sala ${roomCode} já está reservada de ${reservation.startTime} às ${reservation.endTime} por ${reservation.requester}`
            };
        }
    }
    
    return { hasConflict: false };
}

function getEndTime(startTime, duration) {
    const startMinutes = timeToMinutes(startTime);
    const endMinutes = startMinutes + (duration * 60);
    return minutesToTime(endMinutes);
}

// ========== LOGIN FUNCTIONALITY ==========

document.getElementById('loginForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    if (email && password) {
        performLogin('professor', 'João Vitor', 'JV');
    }
});

// Demo buttons for different roles
document.querySelectorAll('.demo-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        const role = btn.dataset.role;
        const roleNames = {
            'professor': 'João Vitor',
            'coordenador': 'Prof. Silva',
            'manutencao': 'Técnico João',
            'admin': 'Admin System'
        };
        const initials = {
            'professor': 'JV',
            'coordenador': 'PS',
            'manutencao': 'TJ',
            'admin': 'AS'
        };
        performLogin(role, roleNames[role], initials[role]);
    });
});

function performLogin(role, name, initials) {
    state.isLoggedIn = true;
    state.currentRole = role;
    state.user = { role, name, initials };
    
    // Hide login, show main app
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('main-app').style.display = 'block';
    
    // Update user info
    document.getElementById('userAvatar').textContent = initials;
    document.getElementById('userName').textContent = name;
    
    // Switch to the selected role
    switchRole(role);
    
    // Initialize components
    initializeApp();
}

// Logout functionality
document.getElementById('logoutBtn')?.addEventListener('click', () => {
    state.isLoggedIn = false;
    state.currentRole = 'professor';
    state.user = null;
    
    document.getElementById('login-page').style.display = 'flex';
    document.getElementById('main-app').style.display = 'none';
    
    // Reset form
    document.getElementById('loginForm').reset();
});

// ========== ROLE SWITCHING ==========

document.querySelectorAll('.role-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const role = btn.dataset.role;
        switchRole(role);
    });
});

function switchRole(role) {
    state.currentRole = role;
    
    // Update active button
    document.querySelectorAll('.role-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.role === role);
    });
    
    // Update navigation menu
    updateNavigation(role);
    
    // Show/hide pages based on role
    updatePageVisibility(role);
    
    // Load dashboard for the role
    switchPage('dashboard');
    
    // Show notification
    showToast(`Perfil alterado para: ${role.charAt(0).toUpperCase() + role.slice(1)}`);
}

function updateNavigation(role) {
    const navItems = {
        'professor': ['dashboard', 'reservas', 'notificacoes'],
        'coordenador': ['dashboard', 'relatorios', 'notificacoes'],
        'manutencao': ['dashboard', 'relatorios', 'notificacoes'],
        'admin': ['dashboard', 'salas', 'problemas', 'usuarios', 'notificacoes']
    };
    
    const items = navItems[role] || [];
    document.querySelectorAll('.nav-item').forEach(item => {
        const page = item.dataset.page;
        item.style.display = items.includes(page) ? 'block' : 'none';
    });
}

function updatePageVisibility(role) {
    // Hide all pages
    document.querySelectorAll('[data-page]').forEach(page => {
        page.style.display = 'none';
    });
    
    // Show appropriate dashboard
    const dashboardId = role === 'professor' ? 'dashboard-page' : `dashboard-page-${role}`;
    const dashboard = document.getElementById(dashboardId);
    if (dashboard) {
        dashboard.style.display = 'block';
    }
}

// ========== PAGE NAVIGATION ==========

document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
        const page = item.dataset.page;
        switchPage(page);
    });
});

function switchPage(page) {
    state.currentPage = page;
    
    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });
    
    // Hide all pages
    document.querySelectorAll('[data-page]').forEach(p => {
        if (!p.classList.contains('page-container')) return;
        p.style.display = 'none';
    });
    
    // Show selected page
    let pageId = `${page}-page`;
    if (page === 'dashboard') {
        pageId = state.currentRole === 'professor' ? 'dashboard-page' : `dashboard-page-${state.currentRole}`;
    }
    
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.style.display = 'block';
    }
}

// ========== PROFESSOR FUNCTIONALITY ==========

// Room selector
function initializeRoomSelector() {
    const selector = document.getElementById('roomSelector');
    if (!selector) return;
    
    selector.innerHTML = '';
    
    // Filter only available rooms
    const availableRooms = state.rooms.filter(room => room.status === 'available');
    
    availableRooms.forEach(room => {
        const option = document.createElement('div');
        option.className = 'room-option';
        option.innerHTML = `
            <div class="room-option-name">${room.name}</div>
            <div class="room-option-capacity">${room.capacity} pessoas</div>
        `;
        option.addEventListener('click', () => {
            document.querySelectorAll('.room-option').forEach(r => r.classList.remove('selected'));
            option.classList.add('selected');
            state.selectedRoom = room;
        });
        selector.appendChild(option);
    });
}

// Availability form with conflict detection
document.getElementById('availabilityForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    
    if (!state.selectedRoom) {
        showToast('Por favor, selecione uma sala', 'error');
        return;
    }
    
    const duration = parseInt(document.getElementById('duration-input').value);
    if (duration > 10) {
        showToast('Duração máxima é 10 horas', 'error');
        return;
    }
    
    const date = document.getElementById('date-input').value;
    const time = document.getElementById('time-input').value;
    const purpose = document.getElementById('purpose-input').value;
    
    // Check for time conflicts
    const roomCode = state.selectedRoom.name.split(' - ')[0];
    const formattedDate = new Date(date).toLocaleDateString('pt-BR');
    // FIX 2: Check for conflict against both 'approved' and 'pending' reservations
    const conflict = hasTimeConflict(roomCode, formattedDate, time, duration, ['approved', 'pending']);
    
    if (conflict.hasConflict) {
        showToast(conflict.message, 'error');
        return;
    }
    
    const endTime = getEndTime(time, duration);
    
    // Create new reservation with unified structure
    const newReservation = {
        id: Math.max(...state.allReservations.map(r => r.id), 0) + 1,
        room: state.selectedRoom.name,
        roomCode: roomCode,
        date: formattedDate,
        startTime: time,
        duration: duration,
        endTime: endTime,
        purpose: purpose,
        status: 'pending',
        requester: state.user.name,
        requesterId: 'prof-' + Math.random().toString(36).substr(2, 9),
        createdAt: new Date().toISOString()
    };
    
    // Add to unified reservations list
    state.allReservations.push(newReservation);
    
    showToast(`Reserva criada com sucesso para ${state.selectedRoom.name}!`);
    
    // Add notification for coordinator
    addNotification({
        type: 'pending',
        title: 'Nova Reserva Pendente',
        message: `${state.user.name} solicitou reserva para ${state.selectedRoom.name} em ${formattedDate} de ${time} às ${endTime}`,
        time: 'agora'
    });
    
    document.getElementById('availabilityForm').reset();
    state.selectedRoom = null;
    initializeRoomSelector();
    
    // Update both professor and coordinator views - SYNCHRONIZED
    renderProfessorReservations();
    updateCoordinatorStats();
});

function renderProfessorReservations() {
    const list = document.getElementById('professorReservationsList');
    if (!list) return;
    
    // Show only current user's reservations
    const userReservations = state.allReservations.filter(r => r.requester === state.user.name);
    
    if (userReservations.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: #999; padding: 40px;">Nenhuma reserva realizada</p>';
        return;
    }
    
    list.innerHTML = userReservations.map(reservation => `
        <div class="reservation-item">
            <div class="reservation-info">
                <h3>${reservation.room}</h3>
                <p>${reservation.date} • ${reservation.startTime} - ${reservation.endTime}</p>
                <p class="reservation-purpose">${reservation.purpose}</p>
            </div>
            <div class="action-buttons">
                <span class="status-badge ${reservation.status}">${reservation.status === 'approved' ? 'Aprovada' : 'Pendente'}</span>
                <button class="btn btn-sm btn-outline" data-action="view-details" data-reservation-id="${reservation.id}">Detalhes</button>
            </div>
        </div>
    `).join('');
}

// Problem report form
document.getElementById('reportProblemForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const room = document.getElementById('problem-room').value;
    const equipment = document.getElementById('problem-equipment').value;
    const description = document.getElementById('problem-description').value;
    
    const newProblem = {
        id: Math.max(...state.problems.map(p => p.id), 0) + 1,
        room: room,
        equipment: equipment,
        description: description,
        status: 'pending',
        priority: 'media',
        date: new Date().toLocaleDateString('pt-BR'),
        reporter: state.user.name
    };
    
    state.problems.push(newProblem);
    showToast('Problema reportado com sucesso!');
    document.getElementById('reportProblemForm').reset();
    
    // Notify maintenance
    addNotification({
        type: 'problem',
        title: 'Novo Problema Reportado',
        message: `Novo problema reportado na ${newProblem.room}: ${newProblem.equipment}`,
        time: 'agora'
    });
    
    // Render problems list if in maintenance view
    renderProblemsList();
});

// ========== COORDENADOR FUNCTIONALITY ==========

// Approve/Reject reservations - SYNCHRONIZED
document.addEventListener('click', (e) => {
    if (e.target.dataset.action === 'approve') {
        const reservationId = parseInt(e.target.closest('.reservation-item').dataset.reservationId);
        const reservation = state.allReservations.find(r => r.id === reservationId);
        
        if (reservation) {
            // FIX: Check for conflict with *other* approved reservations before approving
            // FIX 3: Coordinator approval must check for conflicts only against already APPROVED reservations.
            // If it conflicts with a PENDING one, the coordinator can still approve it (and the other PENDING one will be rejected later, or the coordinator will handle it).
            // The critical conflict is with an APPROVED reservation.
            const conflict = hasTimeConflict(reservation.roomCode, reservation.date, reservation.startTime, reservation.duration, ['approved'], reservation.id);
            
            if (conflict.hasConflict) {
                showToast(`Não foi possível aprovar: Conflito com reserva já APROVADA: ${conflict.conflictingReservation.requester} (${conflict.conflictingReservation.startTime} - ${conflict.conflictingReservation.endTime})`, 'error');
                return;
            }
            
            reservation.status = 'approved';
            reservation.approvedBy = state.user.name;
            e.target.closest('.reservation-item').remove();
            updateCoordinatorStats();
            showToast('Reserva aprovada com sucesso!');
            
            // Add notification to professor
            addNotification({
                type: 'approval',
                title: 'Reserva Aprovada',
                message: `Sua reserva para ${reservation.room} em ${reservation.date} de ${reservation.startTime} às ${reservation.endTime} foi aprovada!`,
                time: 'agora'
            });
            
            // Update professor view
            renderProfessorReservations();
        }
    }
    
    if (e.target.dataset.action === 'reject') {
        const reservationId = parseInt(e.target.closest('.reservation-item').dataset.reservationId);
        const reservation = state.allReservations.find(r => r.id === reservationId);
        
        if (reservation) {
            reservation.status = 'rejected';
            e.target.closest('.reservation-item').remove();
            updateCoordinatorStats();
            showToast('Reserva rejeitada!');
            
            // Add notification to professor
            addNotification({
                type: 'rejection',
                title: 'Reserva Rejeitada',
                message: `Sua reserva para ${reservation.room} em ${reservation.date} foi rejeitada.`,
                time: 'agora'
            });
            
            // Update professor view
            renderProfessorReservations();
        }
    }
});

function updateCoordinatorStats() {
    const pending = state.allReservations.filter(r => r.status === 'pending').length;
    const approved = state.allReservations.filter(r => r.status === 'approved').length;
    
    const pendingEl = document.getElementById('coordPendingCount');
    const approvedEl = document.getElementById('coordApprovedToday');
    
    if (pendingEl) pendingEl.textContent = pending;
    if (approvedEl) approvedEl.textContent = approved;
    
    // Re-render pending list
    renderCoordinatorPendingList();
}

function renderCoordinatorPendingList() {
    const list = document.getElementById('coordenadorPendingList');
    if (!list) return;
    
    // Get pending reservations sorted by creation time (oldest first - FIFO)
    const pending = state.allReservations
        .filter(r => r.status === 'pending')
        .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    
    if (pending.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: #999; padding: 40px;">Nenhuma reserva pendente</p>';
        return;
    }
    
    list.innerHTML = pending.map(reservation => `
        <div class="reservation-item" data-reservation-id="${reservation.id}">
            <div class="reservation-info">
                <h3>${reservation.room}</h3>
                <p>${reservation.date} • ${reservation.startTime} - ${reservation.endTime}</p>
                <p class="reservation-purpose">${reservation.purpose}</p>
                <p style="font-size: 12px; color: #999; margin-top: 8px;">Solicitado por: ${reservation.requester}</p>
            </div>
            <div class="action-buttons">
                <button class="btn btn-primary btn-sm" data-action="approve">Aprovar</button>
                <button class="btn btn-secondary btn-sm" data-action="reject">Rejeitar</button>
            </div>
        </div>
    `).join('');
}

// ========== ADMIN FUNCTIONALITY ==========

// Add room form
document.getElementById('addRoomForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('room-name').value;
    const capacity = parseInt(document.getElementById('room-capacity').value);
    const building = document.getElementById('room-building').value;
    
    const newRoom = {
        id: Math.max(...state.rooms.map(r => r.id)) + 1,
        name: name,
        capacity: capacity,
        building: building,
        status: 'available',
        equipment: 'Equipamentos padrão'
    };
    
    state.rooms.push(newRoom);
    showToast('Sala cadastrada com sucesso!');
    document.getElementById('addRoomForm').reset();
    renderRoomsList();
});

function renderRoomsList() {
    const list = document.getElementById('roomsList');
    if (!list) return;
    
    list.innerHTML = state.rooms.map(room => `
        <div class="reservation-item">
            <div class="reservation-info">
                <h3>${room.name}</h3>
                <p>Prédio: ${room.building} • Andar: ${room.floor} • Capacidade: ${room.capacity} pessoas</p>
                <p class="reservation-purpose">Equipamentos: ${room.equipment}</p>
            </div>
            <span class="status-badge ${room.status === 'available' ? 'approved' : 'pending'}">${room.status === 'available' ? 'Disponível' : 'Manutenção'}</span>
        </div>
    `).join('');
}

function renderProblemsList() {
    const list = document.getElementById('maintenanceProblems');
    if (!list) return;
    
    // FIX: Get filter from the active tab or the list container data attribute
    const activeTab = document.querySelector('.filter-tabs .tab-button.active');
    const statusFilter = activeTab ? activeTab.dataset.filter : 'all';
    
    let filtered = state.problems;
    if (statusFilter !== 'all') {
        filtered = state.problems.filter(p => p.status === statusFilter);
    }
    
    if (filtered.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: #999; padding: 40px;">Nenhum problema encontrado</p>';
        return;
    }
    
    list.innerHTML = filtered.map(problem => `
        <div class="reservation-item">
            <div class="reservation-info">
                <h3>${problem.room} - ${problem.equipment}</h3>
                <p>${problem.date} • Prioridade: <span class="priority-badge priority-${problem.priority}">${problem.priority}</span></p>
                <p class="reservation-purpose">${problem.description}</p>
                <p style="font-size: 12px; color: #999; margin-top: 8px;">Reportado por: ${problem.reporter}</p>
            </div>
            <span class="status-badge ${problem.status === 'pending' ? 'pending' : problem.status === 'in-progress' ? 'warning' : 'approved'}">
                ${problem.status === 'pending' ? 'Pendente' : problem.status === 'in-progress' ? 'Em Progresso' : 'Resolvido'}
            </span>
        </div>
    `).join('');
}

// Add user form
document.getElementById('addUserForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('user-email').value;
    const name = document.getElementById('user-name').value;
    const role = document.getElementById('user-role').value;
    
    showToast(`Usuário ${name} adicionado com sucesso!`);
    document.getElementById('addUserForm').reset();
});

// ========== NOTIFICATIONS ==========

document.getElementById('markAllReadBtn')?.addEventListener('click', () => {
    state.notifications.forEach(n => n.read = true);
    renderNotifications();
    updateNotificationBadge();
    showToast('Todas as notificações marcadas como lidas');
});

function renderNotifications() {
    const list = document.getElementById('notificationsList');
    if (!list) return;
    
    list.innerHTML = state.notifications.map(notification => `
        <div class="notification-item ${notification.read ? '' : 'unread'}">
            <div class="notification-icon" style="background: ${getNotificationColor(notification.type)};">
                ${getNotificationIcon(notification.type)}
            </div>
            <div class="notification-content">
                <h4>${notification.title}</h4>
                <p>${notification.message}</p>
                <span class="notification-time">${notification.time}</span>
            </div>
            <button class="btn-icon" title="Marcar como lida" onclick="markNotificationAsRead(${notification.id})">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </button>
        </div>
    `).join('');
}

function getNotificationColor(type) {
    const colors = {
        'approval': '#e8f0e0',
        'maintenance': '#fecaca',
        'pending': '#fef3c7',
        'problem': '#fef3c7',
        'rejection': '#fecaca'
    };
    return colors[type] || '#e8f0e0';
}

function getNotificationIcon(type) {
    const icons = {
        'approval': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M9 11l3 3L22 4" stroke="#2d5016" stroke-width="2" stroke-linecap="round"/></svg>',
        'maintenance': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 9v2m0 4v2m7.07-7.07a9 9 0 11-12.14 0" stroke="#dc2626" stroke-width="2"/></svg>',
        'pending': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="1" fill="#d97706"/><circle cx="19" cy="12" r="1" fill="#d97706"/><circle cx="5" cy="12" r="1" fill="#d97706"/></svg>',
        'problem': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="1" fill="#d97706"/><circle cx="19" cy="12" r="1" fill="#d97706"/><circle cx="5" cy="12" r="1" fill="#d97706"/></svg>',
        'rejection': '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 9v2m0 4v2m7.07-7.07a9 9 0 11-12.14 0" stroke="#dc2626" stroke-width="2"/></svg>'
    };
    return icons[type] || icons['approval'];
}

function markNotificationAsRead(id) {
    const notification = state.notifications.find(n => n.id === id);
    if (notification) {
        notification.read = true;
        renderNotifications();
        updateNotificationBadge();
    }
}

function addNotification(notification) {
    state.notifications.unshift({
        id: Math.max(...state.notifications.map(n => n.id), 0) + 1,
        ...notification,
        read: false
    });
    updateNotificationBadge();
}

function updateNotificationBadge() {
    const unreadCount = state.notifications.filter(n => !n.read).length;
    const badge = document.getElementById('notificationCount');
    if (badge) {
        badge.textContent = unreadCount;
        badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    }
}

// ========== MODAL FUNCTIONALITY ==========

const modal = document.getElementById('reservationModal');
const closeBtn = document.getElementById('closeModalBtn');

closeBtn?.addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// View reservation details
document.addEventListener('click', (e) => {
    if (e.target.dataset.action === 'view-details') {
        const reservationId = parseInt(e.target.dataset.reservationId);
        const reservation = state.allReservations.find(r => r.id === reservationId);
        
        if (reservation) {
            showReservationDetails(reservation);
        }
    }
});

function showReservationDetails(reservation) {
    document.getElementById('detailRoom').textContent = reservation.room;
    document.getElementById('detailDate').textContent = reservation.date;
    document.getElementById('detailTime').textContent = `${reservation.startTime} - ${reservation.endTime}`;
    document.getElementById('detailRequester').textContent = reservation.requester;
    document.getElementById('detailPurpose').textContent = reservation.purpose;
    document.getElementById('detailStatus').innerHTML = `<span class="status-badge ${reservation.status}">${reservation.status === 'approved' ? 'Aprovada' : 'Pendente'}</span>`;
    
    // History timeline
    const timeline = document.getElementById('historyTimeline');
    timeline.innerHTML = `
        <div class="timeline-item">
            <div class="timeline-marker"></div>
            <div class="timeline-content">
                <p class="timeline-title">Reserva Criada</p>
                <p class="timeline-time">${new Date(reservation.createdAt).toLocaleString('pt-BR')}</p>
            </div>
        </div>
        ${reservation.status === 'approved' ? `
        <div class="timeline-item">
            <div class="timeline-marker"></div>
            <div class="timeline-content">
                <p class="timeline-title">Aprovada por ${reservation.approvedBy}</p>
                <p class="timeline-time">Aprovado</p>
            </div>
        </div>
        ` : ''}
    `;
    
    // Room status
    const roomStatus = document.getElementById('roomStatus');
    const room = state.rooms.find(r => reservation.room.includes(r.name.split(' - ')[0]));
    roomStatus.innerHTML = `
        <div class="status-item">
            <span class="status-label">Status da Sala</span>
            <span class="status-value">${room?.status === 'available' ? 'Disponível' : 'Em Manutenção'}</span>
        </div>
        <div class="status-item">
            <span class="status-label">Equipamentos</span>
            <span class="status-value">${room?.equipment || 'Equipamentos padrão'}</span>
        </div>
    `;
    
    modal.style.display = 'block';
}

// ========== EXPORT FUNCTIONALITY ==========

document.getElementById('exportPdfBtn')?.addEventListener('click', () => {
    showToast('Exportando relatório em PDF...');
    setTimeout(() => {
        showToast('Relatório exportado com sucesso!');
    }, 1500);
});

document.getElementById('exportCsvBtn')?.addEventListener('click', () => {
    showToast('Exportando relatório em CSV...');
    setTimeout(() => {
        showToast('Relatório exportado com sucesso!');
    }, 1500);
});

// ========== TOAST NOTIFICATIONS ==========

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ========== INITIALIZATION ==========

function initializeApp() {
    initializeRoomSelector();
    renderNotifications();
    updateNotificationBadge();
    updateCoordinatorStats();
    renderRoomsList();
    renderProblemsList();
    renderProfessorReservations();
    
    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('date-input');
    if (dateInput) {
        dateInput.value = today;
        dateInput.min = today;
    }
}

// Initialize on page load - SHOW LOGIN PAGE
window.addEventListener('load', () => {
    document.getElementById('login-page').style.display = 'flex';
    document.getElementById('main-app').style.display = 'none';
});

// Filter problems by status
document.querySelectorAll('.filter-tabs .tab-button').forEach(button => {
    button.addEventListener('click', (e) => {
        // 1. Update active tab
        document.querySelectorAll('.filter-tabs .tab-button').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        
        // 2. Update the filter value (simulating a select change)
        const filterValue = e.target.dataset.filter;
        // We need a hidden input or a state variable to hold the filter value
        // Since there is no hidden input, we will use a global state variable or a data attribute on the list container
        // For simplicity, let's assume we can set a data attribute on the list container
        document.getElementById('maintenanceProblems').dataset.filter = filterValue;
        
        // 3. Re-render the list
        renderProblemsList();
    });
});

// Remove the incorrect event listener if it exists
// document.getElementById('problemStatusFilter')?.addEventListener('change', () => {
//     renderProblemsList();
// });

// Add CSS for toast notifications and other styles
const style = document.createElement('style');
style.textContent = `
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #2d5016;
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 9999;
        opacity: 0;
        transform: translateY(20px);
        transition: all 300ms ease-in-out;
        font-size: 14px;
        font-weight: 500;
    }
    
    .toast.show {
        opacity: 1;
        transform: translateY(0);
    }
    
    .toast-error {
        background: #dc2626;
    }
    
    .toast-warning {
        background: #d97706;
    }
    
    .timeline-item {
        display: flex;
        margin-bottom: 24px;
        position: relative;
    }
    
    .timeline-marker {
        width: 12px;
        height: 12px;
        background: #2d5016;
        border-radius: 50%;
        margin-top: 4px;
        margin-right: 16px;
        flex-shrink: 0;
    }
    
    .timeline-content {
        flex: 1;
    }
    
    .timeline-title {
        font-weight: 600;
        margin-bottom: 4px;
        color: #1f2937;
    }
    
    .timeline-time {
        font-size: 12px;
        color: #6b7280;
    }
    
    .status-item {
        display: flex;
        justify-content: space-between;
        padding: 12px 0;
        border-bottom: 1px solid #e5e7eb;
    }
    
    .status-item:last-child {
        border-bottom: none;
    }
    
    .status-label {
        font-weight: 600;
        color: #6b7280;
    }
    
    .status-value {
        color: #1f2937;
    }
`;
document.head.appendChild(style);
